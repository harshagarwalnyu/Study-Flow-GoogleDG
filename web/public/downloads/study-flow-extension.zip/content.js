var e={brightspace:[`.d2l-page-main`,`.d2l-content-container`,`#ContentView`],gradescope:[`.submissionContent`,`.rubricContent`,`.questionContent`]};function t(e){let t=e.toLowerCase();return t.includes(`brightspace`)?`brightspace`:t.includes(`gradescope.com`)?`gradescope`:null}function n(t,n){for(let r of e[n]){let e=t.querySelector(r)?.innerText.trim();if(e)return e}return(t.body.innerText||``).trim()}function r(e){return`${e.slice(0,100)}|${e.length}`}function i(e,t){if(t===`brightspace`){let t=e.querySelector(`a[href*="/DirectFile"]`);if(t?.href){let e=t.getAttribute(`title`)?.replace(`Download `,``)||`brightspace-file.pdf`;return{pdfUrl:t.href,filename:e}}let n=window.location.href.match(/\/le\/(?:lessons|content)\/(\d+)\/(?:topics|viewContent)\/(\d+)/);if(n){let[e,t,r]=n;return{pdfUrl:`${window.location.origin}/d2l/le/content/${t}/topics/files/download/${r}/DirectFile`,filename:`brightspace-captured.pdf`}}let r=e.querySelector(`iframe[src*="pdfjs"]`);if(r?.src){let e=new URLSearchParams(new URL(r.src).search).get(`file`);if(e)return{pdfUrl:e,filename:`embedded-pdf.pdf`}}}return null}function a(e,t,n,r,i){return{rawContent:e,courseName:t,sourcePlatform:n,pdfUrl:r,filename:i}}(function(){let e=`data-study-flow-content`;if(document.documentElement.getAttribute(e))return;document.documentElement.setAttribute(e,`1`);let o=t(window.location.hostname);if(!o)return;let s=n(document,o),c=i(document,o);if(!s&&!c)return;let l=r(s||(c?.pdfUrl??``)),u=`studyflow_last_hash`,d=localStorage.getItem(u)===l;localStorage.setItem(u,l);let f=!1;if(!d){let e={type:`INGEST_PAGE`,payload:a(s||`PDF Content Detected`,document.title,o,c?.pdfUrl,c?.filename)};chrome.runtime.sendMessage(e),f=!0}let p=document.createElement(`div`);p.id=`studyflow-fab-host`,document.body.appendChild(p);let m=p.attachShadow({mode:`closed`}),h=document.createElement(`style`);h.textContent=`
    * { box-sizing: border-box; margin: 0; padding: 0; }
    .fab {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 999999;
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: #3ee0d0;
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      font-size: 20px;
      color: #101620;
      transition: transform 0.15s ease;
    }
    .fab:hover { transform: scale(1.08); }
    .fab .badge {
      position: absolute;
      top: -4px;
      right: -4px;
      font-size: 9px;
      font-weight: 700;
      background: #101620;
      color: #3ee0d0;
      padding: 2px 5px;
      border-radius: 8px;
      pointer-events: none;
    }
    .panel {
      position: fixed;
      bottom: 76px;
      right: 20px;
      z-index: 999999;
      background: #101620;
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 12px;
      padding: 12px;
      display: none;
      flex-direction: column;
      gap: 8px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.4);
      min-width: 150px;
    }
    .panel.open { display: flex; }
    .panel button {
      background: rgba(62,224,208,0.12);
      color: #3ee0d0;
      border: 1px solid rgba(62,224,208,0.25);
      border-radius: 8px;
      padding: 8px 14px;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      transition: background 0.15s ease;
    }
    .panel button:hover {
      background: rgba(62,224,208,0.22);
    }
  `,m.appendChild(h);let g=document.createElement(`button`);g.className=`fab`,g.innerHTML=`&#9733;`,g.title=`Study Flow`,m.appendChild(g);let _=document.createElement(`span`);_.className=`badge`,_.textContent=`Ingested`,_.style.display=f?`block`:`none`,g.appendChild(_);let v=document.createElement(`div`);v.className=`panel`,m.appendChild(v);let y=document.createElement(`button`);y.textContent=`Explain this`,v.appendChild(y);let b=document.createElement(`button`);b.textContent=`Quiz me`,v.appendChild(b),g.addEventListener(`click`,()=>{v.classList.toggle(`open`)}),y.addEventListener(`click`,()=>{let e={type:`OPEN_ASK`,payload:{selectedText:window.getSelection()?.toString()||(s?s.slice(0,500):``)}};chrome.runtime.sendMessage(e),v.classList.remove(`open`)}),b.addEventListener(`click`,()=>{chrome.runtime.sendMessage({type:`OPEN_QUIZ`}),v.classList.remove(`open`)}),console.info(`[Study Flow] Content script loaded on`,o,window.location.href)})();